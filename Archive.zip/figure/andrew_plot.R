source("setup.R")
library(ggplot2)

df = mutate(crashes.year.county, rate = n_crash / County.Population * 100000)
gb = group_by(df, County)
toplot = summarize(gb, avg = mean(rate), delta = rate[12]-rate[1])
toplot = toplot[order(toplot$avg, decreasing = T), ]
cc=cincome[914:996,1:2]
toplot$income=cc$county.percapita.income[match(cc$County,toplot$County)]

pp=cpop[which(cpop$year==2015),][,c(1,3)]
toplot$population=pp$County.Population[match(pp$County,toplot$County)]


summplot = ggplot(toplot[1:20,], aes(x = avg, y = delta, label = County,color=income,size=population)) +
  geom_point()+ geom_text(col=1) + xlab("Average Annual Rate of Crashes per 100k") + 
  ylab("Change in Annual Crash Rate from 2004-2015") + 
  ggtitle("Bicycling Crashes from 2004-2015")+ theme_bw()+ 
  scale_colour_gradient(low = "blue",high="red")
summplot


